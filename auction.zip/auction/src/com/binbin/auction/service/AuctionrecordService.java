package com.binbin.auction.service;

public interface AuctionrecordService {
}
