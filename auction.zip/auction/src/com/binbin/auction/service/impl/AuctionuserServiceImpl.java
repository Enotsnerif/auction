package com.binbin.auction.service.impl;

import com.binbin.auction.dao.AuctionuserDao;
import com.binbin.auction.dao.impl.AuctionuserDaoImpl;
import com.binbin.auction.domain.Auctionuser;
import com.binbin.auction.service.AuctionuserService;

import java.sql.SQLException;

public class AuctionuserServiceImpl implements AuctionuserService {

    //获取dao的对象
    AuctionuserDao auctionuserDao = new AuctionuserDaoImpl();

    @Override
    public Auctionuser getAuctionuserByUsernmaeAndUserpassowrd(String username, String userpassword) throws SQLException, ClassNotFoundException {
        //业务代码
        //调用dao的方法
        Auctionuser auctionuser = auctionuserDao.getAuctionuserByUsernameAndUserpassword(username, userpassword);

        return auctionuser;
    }
}
