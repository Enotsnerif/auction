package com.binbin.auction.service.impl;

import com.binbin.auction.dao.AuctionDao;
import com.binbin.auction.dao.impl.AuctionDaoImpl;
import com.binbin.auction.domain.Auction;
import com.binbin.auction.service.AuctionService;

import java.util.List;

public class AuctionServiceImpl implements AuctionService {

    AuctionDao auctionDao = new AuctionDaoImpl();

    @Override
    public List<Auction> getAuctionList() {
        //调用dao层方法
        return auctionDao.getAuctionList();
    }

    @Override
    public Auction getAuctionById(Integer auctionid) {
        Auction auction = auctionDao.getAuctionById(auctionid);
        return auction;
    }


}
