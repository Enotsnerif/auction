package com.binbin.auction.service;
import com.binbin.auction.domain.*;

import java.sql.SQLException;

public interface AuctionuserService {

    Auctionuser getAuctionuserByUsernmaeAndUserpassowrd(String username, String userpassword) throws SQLException, ClassNotFoundException;

}
