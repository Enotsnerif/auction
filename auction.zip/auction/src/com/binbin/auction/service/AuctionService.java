package com.binbin.auction.service;

import com.binbin.auction.domain.Auction;

import java.util.List;

public interface AuctionService {
    /*
    * 获取所有的拍品
    * @return 拍品的集合
    * */
    List<Auction> getAuctionList();

    Auction getAuctionById(Integer auctionid);

}
