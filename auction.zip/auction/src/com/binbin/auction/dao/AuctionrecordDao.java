package com.binbin.auction.dao;

public interface AuctionrecordDao {
}
