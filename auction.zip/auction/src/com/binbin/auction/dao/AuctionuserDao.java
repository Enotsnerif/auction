package com.binbin.auction.dao;

import com.binbin.auction.domain.Auctionuser;

import java.sql.SQLException;

public interface AuctionuserDao {

    Auctionuser getAuctionuserByUsernameAndUserpassword(String username, String userpassword) throws ClassNotFoundException, SQLException;

}
