package com.binbin.auction.dao;

import com.binbin.auction.domain.Auction;

import java.util.List;

public interface AuctionDao {
    Auction getAuctionById(Integer auctionid);
    /*
     * 获取所有的拍品
     * @return 拍品的集合
     * */
    List<Auction> getAuctionList();


}
