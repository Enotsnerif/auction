package com.binbin.auction.dao.impl;

import java.sql.*;

import com.binbin.auction.dao.AuctionuserDao;
import com.binbin.auction.domain.Auctionuser;

public class AuctionuserDaoImpl implements AuctionuserDao {
    //    static String a,b;
    @Override
    public Auctionuser getAuctionuserByUsernameAndUserpassword(String username, String userpassword)  {
        //使用jdbc连接数据库

        Connection conn =  null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            //1.注册驱动
            //Class.forName("com.mysql.cj.jdbc.Driver");
            Class.forName("com.mysql.jdbc.Driver");
            //2获取连接     处理java到数据库的中文乱码 ?useUnicode=true&characterEncoding=UTF8
            String url = "jdbc:mysql://localhost:3306/auctiondb?useUnicode=true&characterEncoding=UTF8";
            String user = "root";
            String password = "";
            conn =  DriverManager.getConnection(url, user, password);
            //3.创建sql运输车  PreparedStatement  ?占位符
            String sql = "SELECT * from auctionuser where userName = ? and userPassword = ?";
            ps = conn.prepareStatement(sql);
            //给占位符赋值
            ps.setString(1, username);
            ps.setString(2, userpassword);
            //4.发送查询的sql语句
            rs = ps.executeQuery();
            //5.处理结果集
            Auctionuser auctionuser = null;
            if(rs.next()){
                auctionuser = new Auctionuser();
                auctionuser.setUsername(rs.getString("userName"));
                auctionuser.setUserisadmin(rs.getInt("userIsadmin"));
            }

            return auctionuser;

        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally {
            try {
                if(rs != null)
                    rs.close();
                if(ps != null)
                    ps.close();
                if(conn != null)
                    conn.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }
        return null;
    }

}