package com.binbin.auction.dao.impl;

import com.binbin.auction.dao.AuctionDao;
import com.binbin.auction.domain.Auction;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AuctionDaoImpl implements AuctionDao {

    @Override
    public  List<Auction> getAuctionList() {

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        //创建集合
        List<Auction> auctionList = new ArrayList<>();

        try {
            //1.注册驱动
            //Class.forName("com.mysql.cj.jdbc.Driver");
            Class.forName("com.mysql.jdbc.Driver");
            //2获取连接     处理java到数据库的中文乱码 ?useUnicode=true&characterEncoding=UTF8
            String url = "jdbc:mysql://localhost:3306/auctiondb?useUnicode=true&characterEncoding=UTF8";
            String user = "root";
            String password = "";
            conn =  DriverManager.getConnection(url, user, password);
            //3.创建sql运输车  PreparedStatement  ?占位符
            String sql = "SELECT * from auction";
            ps = conn.prepareStatement(sql);
            /*a=username;
            b=userpassword;*/
            //4.发送查询的sql语句
            rs = ps.executeQuery();
            //5.处理结果集
            while (rs.next()) {
                Auction auction = new Auction();
                //封装数据
                auction.setAuctionid(rs.getInt("auctionId"));
                auction.setAuctionname(rs.getString("auctionName"));
                auction.setAuctionstartprice(rs.getDouble("auctionStartPrice"));
                auction.setAuctionupset(rs.getDouble("auctionUpset"));
                auction.setAuctionstarttime(rs.getDate("auctionStartTime"));
                auction.setAuctionendtime(rs.getDate("auctionEndTime"));
                auction.setAuctionpic(rs.getString("auctionPic"));
                auction.setAuctionpictype(rs.getString("auctionPicType"));
                auction.setAuctiondesc(rs.getString("auctionDesc"));

                //保存到集合
                auctionList.add(auction);

            }
            return auctionList;

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally {
            try {
                if(rs != null)
                    rs.close();
                if(ps != null)
                    ps.close();
                if(conn != null)
                    conn.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }
        return null;
    }

    Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    @Override
    public Auction getAuctionById(Integer auctionid) {
        try {

            //1.注册驱动
            //Class.forName("com.mysql.cj.jdbc.Driver");
            Class.forName("com.mysql.jdbc.Driver");
            //2获取连接     处理java到数据库的中文乱码 ?useUnicode=true&characterEncoding=UTF8
            String url = "jdbc:mysql://localhost:3306/auctiondb?useUnicode=true&characterEncoding=UTF8";
            String user = "root";
            String password = "";
            conn =  DriverManager.getConnection(url, user, password);
            //3.创建sql运输车  PreparedStatement  ?占位符
            String sql = "SELECT * from auction where auctionid = ?";
            ps.setInt(1,auctionid);
            ps = conn.prepareStatement(sql);
            /*a=username;
            b=userpassword;*/
            //4.发送查询的sql语句
            rs = ps.executeQuery();
            //5.处理结果集
            Auction auction = null;
            if(rs.next()) {
                auction = new Auction();
                //封装数据
                auction.setAuctionid(rs.getInt("auctionId"));
                auction.setAuctionname(rs.getString("auctionName"));
                auction.setAuctionstartprice(rs.getDouble("auctionStartPrice"));
                auction.setAuctionupset(rs.getDouble("auctionUpset"));
                auction.setAuctionstarttime(rs.getDate("auctionStartTime"));
                auction.setAuctionendtime(rs.getDate("auctionEndTime"));
                auction.setAuctionpic(rs.getString("auctionPic"));
                auction.setAuctionpictype(rs.getString("auctionPicType"));
                auction.setAuctiondesc(rs.getString("auctionDesc"));
            }
            return auction;

        } catch (ClassNotFoundException | SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }finally {
            try {
                if(rs != null)
                    rs.close();
                if(ps != null)
                    ps.close();
                if(conn != null)
                    conn.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }
        return null;
    }


}
