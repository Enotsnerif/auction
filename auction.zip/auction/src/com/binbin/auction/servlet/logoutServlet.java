package com.binbin.auction.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/logoutServlet")
public class logoutServlet extends HttpServlet {

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //退出功能
        //清空session回到登录页面
        request.getSession().invalidate();
        //获取项目在服务器的根路径
        response.sendRedirect(request.getContextPath() + "/login.jsp");
    }
}
