package com.binbin.auction.servlet;

import com.binbin.auction.domain.Auction;
import com.binbin.auction.service.AuctionService;
import com.binbin.auction.service.impl.AuctionServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/indexServlet")
public class indexServlet extends HttpServlet {

    AuctionService auctionService = new AuctionServiceImpl();

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //查询所有auction

        //获取数据

        //封装数据

        //调用业务层APL（方法）
        List<Auction> auctionList = auctionService.getAuctionList();
        //响应
        request.setAttribute("auctionList",auctionList);
        request.getRequestDispatcher("index.jsp").forward(request,response);




    }
}
