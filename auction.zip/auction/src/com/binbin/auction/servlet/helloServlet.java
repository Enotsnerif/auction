package com.binbin.auction.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/hello")//注解方式配置servlet给一个映射路径
public class helloServlet extends HttpServlet {//extends继承   要成为Servlet就继承HttpServlet

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取请求数据name
        //request请求对象
        String name =  request.getParameter("name");
        System.out.println(name);
        //跳转到index.jsp
        request.getRequestDispatcher("index.jsp").forward(request,response);


    }
    /*
    //接收get请求
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doGet(req, resp);
    }
    //接收post请求
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doPost(req, resp);
    }
 */


    //是get变成get是post变成post


}
