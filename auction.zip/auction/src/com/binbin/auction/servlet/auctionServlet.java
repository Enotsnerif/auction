package com.binbin.auction.servlet;

import com.binbin.auction.domain.Auction;
import com.binbin.auction.service.AuctionService;
import com.binbin.auction.service.impl.AuctionServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/auctionServlet")
public class auctionServlet extends HttpServlet {


    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


        AuctionService auctionService = new AuctionServiceImpl();
        //获取请求中的id
        Integer auctionid = Integer.valueOf(request.getParameter("auctionid"));
        Auction auction = auctionService.getAuctionById(auctionid);
        //响应
        request.setAttribute("auction",auction);
        request.getRequestDispatcher("auction.jsp").forward(request,response);

    }
}
