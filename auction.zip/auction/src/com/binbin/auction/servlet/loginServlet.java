package com.binbin.auction.servlet;

import com.binbin.auction.domain.Auctionuser;
import com.binbin.auction.service.AuctionuserService;
import com.binbin.auction.service.impl.AuctionuserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {

    //获取业务层对象
    AuctionuserService auctionuserService = new AuctionuserServiceImpl();
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //处理post的乱码
        request.setCharacterEncoding("utf-8");
        //获取数据
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        System.out.println("用户名:"+ username);
        System.out.println("密码:"+ password);

        //调用业务层API
        Auctionuser auctionuser = null;
        try {
            auctionuser = auctionuserService.getAuctionuserByUsernmaeAndUserpassowrd(username,password);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        //判断用户名和密码是否正确
        if(auctionuser!=null){//登陆成功
            //跳转页面 重定向
            //获取session对象
            HttpSession session = request.getSession();
            //保存数据
            //一个会话有效，同一个浏览器 为了在前端页面显示用户信息
            session.setAttribute("userInfo",auctionuser);
            response.sendRedirect("indexServlet");

        }
        else {//登陆失败
            //转发
            //page request session application
            //返回提示信息 ${msg}el表达式， msg为key通过key获取value(object)
            //同一个请求有效
            request.setAttribute("msg","用户名或者密码错误！请重新登录！");



            request.getRequestDispatcher("login.jsp").forward(request,response);
////判断用户名和密码是否正确
//            if("张三".equals(username)&&"123456".equals(password)){//登陆成功
//                //跳转页面
//                response.sendRedirect("index.jsp");
//            }
//            else {//登陆失败
//                request.getRequestDispatcher("login.jsp").forward(request,response);


        }


    }
}
